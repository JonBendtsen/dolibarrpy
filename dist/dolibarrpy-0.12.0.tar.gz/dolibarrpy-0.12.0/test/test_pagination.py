from dolibarrpy import Dolibarrpy, ContactFilter, DolibarrListError
import time

# Initialiser med dine rigtige credentials
api = Dolibarrpy(
    url='https://jon:gNJXAv5Xxp4eyd@admin.balboaswing.dk/api/index.php/',
    token='32LqAA6ejzRi7e7v23XM54tsPKM6dGVa',
    timeout=16,
    debug=True  # VIGTIGT: ser request/response i console
)

print("=" * 60)
print("TEST 1: Grundlæggende paginering")
print("=" * 60)

start_time = time.time()
contacts = api.find_all_contacts()
duration = time.time() - start_time

print(f"Antal contacts: {len(contacts)}")
print(f"Tid for eksport: {duration:.1f} sekunder")
print(f"Gennemsnitlig tid pr. side (ca.): {duration / (len(contacts) // 100 + 1):.2f}s")

if len(contacts) > 0:
    print(f"\nFørste kontakt:")
    print(f"  rowid: {contacts[0].get('rowid')}")
    print(f"  ref: {contacts[0].get('ref')}")
    print(f"  label: {contacts[0].get('label')}")
    print(f"  entity: {contacts[0].get('entity')}")

print("\n" + "=" * 60)
print("TEST 2: Eksport med custom limit (10 per side)")
print("=" * 60)

start_time = time.time()
small_contacts = api.find_all_contacts(ContactFilter(limit=10))
duration = time.time() - start_time

print(f"Antal contacts: {len(small_contacts)}")
print(f"Tid for eksport: {duration:.1f} sekunder")
print(f"Forventet antal sider: {len(small_contacts) / 10}")

print("\n" + "=" * 60)
print("TEST 3: Filter med sqlfilters")
print("=" * 60)

start_time = time.time()
filtered = api.find_all_contacts(ContactFilter(
    sqlfilters="(t.rowid:>:'1')"
))
duration = time.time() - start_time

print(f"Antal contacts med rowid > 1: {len(filtered)}")
print(f"Tid: {duration:.1f} sekunder")

if len(filtered) > 0:
    min_id = min(int(c.get('id')) for c in filtered)
    print(f"Laveste id i resultat: {min_id} (skal være > 1)")

print("\n" + "=" * 60)
print("TEST 4: Error handling - ugyldig limit")
print("=" * 60)

try:
    bad = api.find_all_contacts(ContactFilter(limit=0))
    print("❌ FEJL: Burde have kastet exception")
except (ValueError, DolibarrListError) as e:
    print(f"✓ Korrekt fejlhåndtering: {type(e).__name__}")

print("\n" + "=" * 60)
print("TEST 5: Debug-log verificering")
print("=" * 60)

print("Tjek venligst debug-outputtet ovenfor og verifikér:")
print("  ✓ Første request: page=0, limit=100")
print("  ✓ Sortering: sortfield=t.rowid&sortorder=ASC")
print("  ✓ Sidste side er enten tom (< 100 rækker) eller stopper")
print("  ✓ Ingen 'Repeating page' eller 'stuck'-situationer")