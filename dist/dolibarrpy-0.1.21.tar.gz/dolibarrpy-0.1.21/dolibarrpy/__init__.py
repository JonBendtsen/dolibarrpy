from dolibarrpy.dolibarrpy import Dolibarrpy
