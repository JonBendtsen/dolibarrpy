from dolibarrpy.Dolibarrpy import Dolibarrpy
